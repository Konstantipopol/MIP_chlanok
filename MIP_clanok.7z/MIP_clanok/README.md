"# MIP_clanok" 
